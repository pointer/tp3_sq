   #include <iostream>
   #include <vector>
   #include <algorithm>
   #include <fstream>
   #include <sstream>

      struct Edge {
       int src, dest, weight;
       bool operator<(const Edge& other) const {
           return weight < other.weight;
       }
   };

   struct DisjointSets {
       std::vector<int> parent, rank;

       DisjointSets(int n) : parent(n), rank(n, 0) {
           for (int i = 0; i < n; i++) {
               parent[i] = i;
           }
       }

       int find(int u) {
           if (u != parent[u])
               parent[u] = find(parent[u]);
           return parent[u];
       }

       void merge(int x, int y) {
           int rootX = find(x);
           int rootY = find(y);
           if (rootX != rootY) {
               if (rank[rootX] > rank[rootY])
                   parent[rootY] = rootX;
               else if (rank[rootX] < rank[rootY])
                   parent[rootX] = rootY;
               else {
                   parent[rootY] = rootX;
                   rank[rootX]++;
               }
           }
       }
   };

   std::vector<Edge> KruskalMST(std::vector<Edge>& edges, int V) {
       std::sort(edges.begin(), edges.end());
       DisjointSets ds(V);
       std::vector<Edge> result;

       for (Edge& e : edges) {
           if (ds.find(e.src) != ds.find(e.dest)) {
               result.push_back(e);
               ds.merge(e.src, e.dest);
           }
       }
       return result;
   }

int main(int argc, char *argv[])  {

    if (argc != 2)
    {
        std::cerr << "Usage: ./tp3 input_carte.txt" << std::endl;
        return 1;
    }

    std::ifstream infile(argv[1]);


    if (!infile.is_open()) {
        std::cerr << "Failed to open file." << std::endl;
        return 1; // or handle the error as needed
    }
    std::vector<Edge> edges;
    int V = 0; // Number of vertices
    std::string line;
    std::string identifier, colon, semicolon;
    char src, dest;
    int weight;
    while (std::getline(infile, line)) {
        std::istringstream iss(line);
        if (iss >> identifier >> colon >> src >> dest >> weight >> semicolon) {
            edges.push_back({src - 'a', dest - 'a', weight});
            V = std::max(V, std::max(src - 'a', dest - 'a') + 1);
            // std::cout << "Edge added: " << src << " " << dest << " " << weight << std::endl; // Debug output
        }
    }

    std::vector<Edge> mst = KruskalMST(edges, V);
    if (mst.empty()) {
        std::cout << "MST is empty" << std::endl; // Debug output
    }

    int totalWeight = 0;
    for (Edge& e : mst) {
        totalWeight += e.weight;
    }

    // Output vertices
    for (int i = 0; i < V; i++) {
        std::cout << (char)('a' + i) << std::endl;
    }

    // Output edges in the specified format
    for (Edge& e : mst) {
        std::cout << "rue" << e.src << "\t" << (char)('a' + e.src) << "\t" << (char)('a' + e.dest) << "\t" << e.weight << std::endl;
    }

    // Output total weight
    std::cout << "---" << std::endl;
    std::cout << totalWeight << std::endl;

    return 0;
}
